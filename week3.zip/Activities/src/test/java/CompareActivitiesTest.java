public class CompareActivitiesTest {

}
