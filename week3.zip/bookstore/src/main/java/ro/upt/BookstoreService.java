package ro.upt;

/**
 * This is the test class.
 */
public class BookstoreService {
    public double calculateBookPrice(Book book, BookstoreSubscription subscription) {
        if (book.getTitle().isEmpty()) {
            throw new InvalidBookTitleException();
        }

        double totalPrice = book.getNoPages() * 0.25;

        if (subscription.equals(BookstoreSubscription.SUBSCRIPTION)) {
            totalPrice /= 2;
        }

        return totalPrice;
    }
}
